﻿# SpringBootCrudPatterns
Bando de dados PostGresSQL
Olhe no Properties.
A ideia e a integração de um CRUD com uma função sendo refatorada para um design patterns.
